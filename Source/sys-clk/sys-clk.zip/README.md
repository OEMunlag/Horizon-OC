# hoc-clk

Switch sysmodule allowing you to set cpu/gpu/mem clocks according to the running application and docked state.
Modified for Horizon OC